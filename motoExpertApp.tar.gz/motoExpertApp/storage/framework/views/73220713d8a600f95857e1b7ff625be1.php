<!-- Heredamos el contenido base de layout -->

<!-- Aqui vamos a poner el contenido dinámico de nuestra página -->
<?php $__env->startSection('menuelements'); ?>
    <a href="<?php echo e(url('.')); ?>" class="nav-item nav-link"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
    <a href="<?php echo e(url('moto')); ?>" class="nav-item nav-link"><i class="fa fa-motorcycle me-2"></i>Catalog</a>
    <a href="<?php echo e(url('moto/create')); ?>" class="nav-item nav-link"><i class="fa fa-plus me-2"></i>Add Motorcycle</a>
    <hr>
    <a href="<?php echo e(url('settings')); ?>" class="nav-item nav-link active"><i class="fa fa-cog me-2"></i>Settings</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <a href="<?php echo e(url('.')); ?>" class="btn p-0"><i class="fa fa-chevron-left me-2"></i>Go home</a>
</div>

<div class="container-fluid pt-4 px-4">
    <form action="<?php echo e(url('settings')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="row g-4 justify-content-between">
                <div class="col-sm-12 col-xl-6">
                    <div class="bg-secondary rounded h-100 p-4">
                        <h6 class="mb-4">Behaviour after insert a new moto</h6>
                        <div class="form-floating mb-3">
                            <select class="form-select" id="afterInsert" name="afterInsert"
                                aria-label="Floating label select example">
                                <?php $__currentLoopData = $afterCreateOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e($createOption === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="afterInsert">Select what you want to do after insertion</label>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-xl-6">
                    <div class="bg-secondary rounded h-100 p-4">
                        <h6 class="mb-4">Behaviour after edit a moto</h6>
                        <div class="form-floating mb-3">
                            <select class="form-select" id="afterEdit" name="afterEdit"
                                aria-label="Floating label select example">
                                <?php $__currentLoopData = $afterEditOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e($editOption === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="afterEdit">Select what you want to do after edit</label>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-xl-12 text-center justify-center">
                    <button class="btn btn-primary">Apply changes</button>
                </div>
        </div>
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/motoExpertApp/resources/views/settings/index.blade.php ENDPATH**/ ?>