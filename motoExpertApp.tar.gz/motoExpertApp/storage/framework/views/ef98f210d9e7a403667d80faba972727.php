<!-- Heredamos el contenido base de layout -->

<!-- Aqui vamos a poner el contenido dinámico de nuestra página -->
<?php $__env->startSection('menuelements'); ?>
    <a href="<?php echo e(url('.')); ?>" class="nav-item nav-link"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
    <a href="<?php echo e(url('moto')); ?>" class="nav-item nav-link"><i class="fa fa-motorcycle me-2"></i>Catalog</a>
    <a href="<?php echo e(url('moto/create')); ?>" class="nav-item nav-link"><i class="fa fa-plus me-2"></i>Add Motorcycle</a>
    <hr>
    <a href="<?php echo e(url('settings')); ?>" class="nav-item nav-link"><i class="fa fa-cog me-2"></i>Settings</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <a href="<?php echo e(url('moto')); ?>" class="btn p-0"><i class="fa fa-chevron-left me-2"></i>Go catalog</a>
    <br>
    <a href="<?php echo e(url('moto/' . $moto->id)); ?>" class="btn p-0"><i class="fa fa-chevron-left me-2"></i>See moto</a>
</div>

<div class="col-sm-12 col-xl-12 pt-4 px-4">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">Modify moto <?php echo e($moto->id); ?> <?php echo e($moto->brand); ?> <?php echo e($moto->model); ?></h6>
        <form action="<?php echo e(url('moto/' . $moto->id)); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="brand" name="brand" placeholder="Moto brand" maxlength="40" required value="<?php echo e(old('brand', $moto->brand)); ?>">
                <label for="brand">Moto brand</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="model" name="model" placeholder="Moto model" maxlength="60" required value="<?php echo e(old('model', $moto->model)); ?>">
                <label for="model">Moto model</label>
            </div>
            <div class="form-floating mb-3">
                <input type="number" class="form-control" id="year" name="year" placeholder="Year" min="1" max="9999" required value="<?php echo e(old('year', $moto->year)); ?>">
                <label for="year">Year</label>
            </div>
            <div class="form-floating mb-3">
                <input type="number" class="form-control" id="displacement" name="displacement" min="25" max="3000" placeholder="Displacement" required value="<?php echo e(old('displacement', $moto->displacement)); ?>">
                <label for="displacement">Displacement</label>
            </div>
            <div class="form-floating mb-3">
                <input type="number" class="form-control" id="power" name="power" min="1" max="2500" placeholder="Power" value="<?php echo e(old('power', $moto->power)); ?>">
                <label for="power">Power</label>
            </div>
            <div class="form-floating mb-3">
                <select class="form-select" id="license" name="license" aria-label="License type" required value="<?php echo e(old('license', $moto->license)); ?>">
                    <?php
                        $enum = ['AM', 'A1', 'A2', 'A'];
                    ?>
                    <?php $__currentLoopData = $enum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($moto->license == $license || old('license') == $license): ?>
                            <option value="<?php echo e($license); ?>" selected><?php echo e($license); ?></option>
                        <?php else: ?>
                            <option value=<?php echo e($license); ?>><?php echo e($license); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="license">License type</label>
            </div>
            <div class="form-floating mb-3">
                <input type="number" class="form-control" id="weight" name="weight" min="1" max="1500" placeholder="Weight" value="<?php echo e(old('weight', $moto->weight)); ?>">
                <label for="weight">Weight</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="type" name="type" placeholder="Type" maxlength="25" required value="<?php echo e(old('type', $moto->type)); ?>">
                <label for="type">Type</label>
            </div>
            <div class="form-floating mb-3">
                <input type="number" class="form-control" id="prize" name="prize" min="1" step=".01" placeholder="Prize" value="<?php echo e(old('prize', $moto->prize)); ?>">
                <label for="prize">Prize</label>
            </div>
            <div class="form-floating mb-3">
                <button type="submit" class="btn btn-success mt-3">Modify model</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/motoExpertApp/resources/views/moto/edit.blade.php ENDPATH**/ ?>